package com.playerstatistics;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.*;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;
import java.util.logging.Level;

public final class PlayerStatisticsPlugin extends JavaPlugin {

    private static PlayerStatisticsPlugin instance;
    private Gson gson;
    private File dataFile;
    private Map<String, PlayerData> playerDataMap;

    @Override
    public void onEnable() {
        instance = this;
        gson = new GsonBuilder().setPrettyPrinting().create();
        playerDataMap = new HashMap<>();

        saveDefaultConfig();
        setupDataFile();
        loadPlayerData();

        getServer().getPluginManager().registerEvents(new PlayerJoinListener(this), this);

        if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) {
            new PlayerStatisticsExpansion(this).register();
            getLogger().info("PlaceholderAPI expansion registered successfully!");
        } else {
            getLogger().warning("PlaceholderAPI not found! Variables will not work.");
        }

        getCommand("playerstats").setExecutor(new PlayerStatsCommand(this));

        getLogger().info("PlayerStatisticsPlugin has been enabled!");
    }

    @Override
    public void onDisable() {
        savePlayerData();
        getLogger().info("PlayerStatisticsPlugin has been disabled!");
    }

    public static PlayerStatisticsPlugin getInstance() {
        return instance;
    }

    public Gson getGson() {
        return gson;
    }

    private void setupDataFile() {
        File dataFolder = getDataFolder();
        if (!dataFolder.exists()) {
            dataFolder.mkdirs();
        }
        dataFile = new File(dataFolder, "playerdata.json");
    }

    public void loadPlayerData() {
        if (!dataFile.exists()) {
            playerDataMap = new HashMap<>();
            return;
        }

        try (Reader reader = new FileReader(dataFile)) {
            Type type = new TypeToken<Map<String, PlayerData>>(){}.getType();
            playerDataMap = gson.fromJson(reader, type);
            if (playerDataMap == null) {
                playerDataMap = new HashMap<>();
            }
            getLogger().info("Loaded " + playerDataMap.size() + " player records.");
        } catch (IOException e) {
            getLogger().log(Level.SEVERE, "Failed to load player data!", e);
            playerDataMap = new HashMap<>();
        }
    }

    public void savePlayerData() {
        try {
            File tempFile = new File(dataFile.getParent(), dataFile.getName() + ".tmp");
            try (Writer writer = new FileWriter(tempFile)) {
                gson.toJson(playerDataMap, writer);
            }
            Files.move(tempFile.toPath(), dataFile.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            getLogger().info("Saved " + playerDataMap.size() + " player records.");
        } catch (IOException e) {
            getLogger().log(Level.SEVERE, "Failed to save player data!", e);
        }
    }

    public void addPlayerData(String playerName, String uuid) {
        PlayerData data = new PlayerData(playerName, uuid);
        playerDataMap.put(uuid, data);
        savePlayerData();
        getLogger().info("Recorded player: " + playerName + " (" + uuid + ")");
    }

    public int getTotalPlayers() {
        return playerDataMap.size();
    }

    public int getPlayersJoinedSince(LocalDateTime since) {
        int count = 0;
        for (PlayerData data : playerDataMap.values()) {
            if (data.getJoinDate().isAfter(since) || data.getJoinDate().isEqual(since)) {
                count++;
            }
        }
        return count;
    }

    public int getDayPlayerTotal() {
        LocalDateTime dayAgo = LocalDateTime.now().minusDays(1);
        return getPlayersJoinedSince(dayAgo);
    }

    public int getWeekPlayerTotal() {
        LocalDateTime weekAgo = LocalDateTime.now().minusWeeks(1);
        return getPlayersJoinedSince(weekAgo);
    }

    public int getMonthPlayerTotal() {
        LocalDateTime monthAgo = LocalDateTime.now().minusMonths(1);
        return getPlayersJoinedSince(monthAgo);
    }

    public int getYearPlayerTotal() {
        LocalDateTime yearAgo = LocalDateTime.now().minusYears(1);
        return getPlayersJoinedSince(yearAgo);
    }

    public static class PlayerData {
        private final String playerName;
        private final String uuid;
        private final long joinTimestamp;

        public PlayerData(String playerName, String uuid) {
            this.playerName = playerName;
            this.uuid = uuid;
            this.joinTimestamp = System.currentTimeMillis();
        }

        public String getPlayerName() {
            return playerName;
        }

        public String getUuid() {
            return uuid;
        }

        public LocalDateTime getJoinDate() {
            return LocalDateTime.ofInstant(
                java.time.Instant.ofEpochMilli(joinTimestamp),
                ZoneId.systemDefault()
            );
        }

        public long getJoinTimestamp() {
            return joinTimestamp;
        }
    }
}