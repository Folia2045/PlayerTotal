package com.playerstatistics;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import org.jetbrains.annotations.NotNull;

public class PlayerStatisticsExpansion extends PlaceholderExpansion {

    private final PlayerStatisticsPlugin plugin;

    public PlayerStatisticsExpansion(PlayerStatisticsPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    @NotNull
    public String getIdentifier() {
        return "player";
    }

    @Override
    @NotNull
    public String getAuthor() {
        return "YourName";
    }

    @Override
    @NotNull
    public String getVersion() {
        return "1.0.0";
    }

    @Override
    public boolean persist() {
        return true;
    }

    @Override
    public String onRequest(OfflinePlayer player, @NotNull String params) {
        if (params.equals("total")) {
            return String.valueOf(plugin.getTotalPlayers());
        } else if (params.equals("day_player_total")) {
            return String.valueOf(plugin.getDayPlayerTotal());
        } else if (params.equals("week_player_total")) {
            return String.valueOf(plugin.getWeekPlayerTotal());
        } else if (params.equals("mon_player_total")) {
            return String.valueOf(plugin.getMonthPlayerTotal());
        } else if (params.equals("year_player_total")) {
            return String.valueOf(plugin.getYearPlayerTotal());
        }

        return null;
    }
}