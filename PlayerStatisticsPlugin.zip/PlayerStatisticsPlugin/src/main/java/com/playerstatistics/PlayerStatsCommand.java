package com.playerstatistics;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

import java.util.Collections;
import java.util.List;

public class PlayerStatsCommand implements CommandExecutor, TabCompleter {

    private final PlayerStatisticsPlugin plugin;

    public PlayerStatsCommand(PlayerStatisticsPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("playerstats.admin")) {
            sender.sendMessage("§c你没有权限使用此命令！");
            return true;
        }

        if (args.length == 1 && args[0].equalsIgnoreCase("reload")) {
            plugin.loadPlayerData();
            sender.sendMessage("§a玩家统计数据已重新加载！");
            sender.sendMessage("§e当前总玩家数: §f" + plugin.getTotalPlayers());
            sender.sendMessage("§e一日内玩家数: §f" + plugin.getDayPlayerTotal());
            sender.sendMessage("§e一周内玩家数: §f" + plugin.getWeekPlayerTotal());
            sender.sendMessage("§e一月内玩家数: §f" + plugin.getMonthPlayerTotal());
            sender.sendMessage("§e一年内玩家数: §f" + plugin.getYearPlayerTotal());
            return true;
        }

        sender.sendMessage("§6=== 玩家统计插件 ===");
        sender.sendMessage("§e总玩家数: §f" + plugin.getTotalPlayers());
        sender.sendMessage("§e一日内玩家数: §f" + plugin.getDayPlayerTotal());
        sender.sendMessage("§e一周内玩家数: §f" + plugin.getWeekPlayerTotal());
        sender.sendMessage("§e一月内玩家数: §f" + plugin.getMonthPlayerTotal());
        sender.sendMessage("§e一年内玩家数: §f" + plugin.getYearPlayerTotal());
        sender.sendMessage("§7用法: /playerstats reload");

        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1 && sender.hasPermission("playerstats.admin")) {
            return Collections.singletonList("reload");
        }
        return Collections.emptyList();
    }
}